class API
{
  static const hostConnect = "http://192.168.100.9/tugasakhir";
  static const hostConnectUser = "$hostConnect/user";

  static const signUp = "$hostConnectUser/signup.php";
  static const login = "$hostConnectUser/login.php";

}