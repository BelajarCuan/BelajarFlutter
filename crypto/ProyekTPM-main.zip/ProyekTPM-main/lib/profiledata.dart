class datadiri {
  String name;
  String nim;
  String kelas;
  String cita_cita;
  String ttl;
  String image;

  datadiri({
    required this.name,
    required this.nim,
    required this.kelas,
    required this.cita_cita,
    required this.ttl,
    required this.image,

  });
}

var data =[
  datadiri(
      name: 'Jeremy Kevin Alexander Sitorus',
      nim: '123200043',
      kelas: 'IF - B',
      cita_cita: 'Hidup kalian kurang lengkap kalau belum pernah belajar TPM. Pelajaran TPM sangat menyenangkan dan Asik   . Terima Kasih TPM saya Cinta TPM',
      ttl: 'Medan , 7 Desember 2002',
      image: 'assets/image/jeremy.jpeg'),



];
